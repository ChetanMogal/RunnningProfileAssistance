package com.example.admin.runningprofileapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.media.MediaPlayer;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;

public class RegistrationActivity extends AppCompatActivity implements View.OnClickListener{

    private EditText fullname, emailorcontact, password;
    private Button register;
    private TextView loginifregister;
    private ProgressDialog progressDialog;
    String name, email;
    private FirebaseAuth firebaseAuth;
    boolean b = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        firebaseAuth = FirebaseAuth.getInstance();
        if(firebaseAuth.getCurrentUser() != null){
            name=firebaseAuth.getCurrentUser().getDisplayName();
            email=firebaseAuth.getCurrentUser().getEmail();

            finish();
            Intent intent =new Intent(getApplicationContext(), ProfileActivity.class);
            intent.putExtra("name",name);
            intent.putExtra("email",email);
            startActivity(intent);

        }

        progressDialog = new ProgressDialog(this);

        register=(Button) findViewById(R.id.register);
        fullname = (EditText) findViewById(R.id.fullname);
        emailorcontact = (EditText) findViewById(R.id.emailorcontact);
        password = (EditText) findViewById(R.id.password);
        loginifregister = (TextView) findViewById(R.id.loginifregister);

        register.setOnClickListener(this);
        loginifregister.setOnClickListener(this);
    }

    private void registerUser()
    {
        name = fullname.getText().toString().trim();
        email = emailorcontact.getText().toString().trim();
        String pass = password.getText().toString().trim();

        if(TextUtils.isEmpty(email)){
            //email is empty
            Toast.makeText(this,"Please enter the email", Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(name)){
            //name is empty
            Toast.makeText(this,"Please enter the name", Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(pass)){
            //password is empty
            Toast.makeText(this,"Please enter the password", Toast.LENGTH_SHORT).show();
            return;
        }

        progressDialog.setMessage("Registering User...");
        progressDialog.show();

        firebaseAuth.createUserWithEmailAndPassword(email,pass)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>(){
            @Override
            public void onComplete(@NonNull Task<AuthResult> task){
                if(task.isSuccessful()){
                    Toast.makeText(RegistrationActivity.this, "Registered Successfully", Toast.LENGTH_SHORT).show();
                    finish();
                    Intent intent =new Intent(getApplicationContext(), ProfileActivity.class);
                    intent.putExtra("name",name);
                    intent.putExtra("email",email);
                    startActivity(intent);

                }
                else {
                    FirebaseAuthException e = (FirebaseAuthException )task.getException();
                    Toast.makeText(RegistrationActivity.this, "Failed Registration: "+e.getMessage(), Toast.LENGTH_SHORT).show();
                    Toast.makeText(RegistrationActivity.this, "Could not register. Please try again", Toast.LENGTH_SHORT).show();
                    Intent intent  = new Intent(getBaseContext(), RegistrationActivity.class);
                }
            }
        });
    }

    @Override
    public void onClick(View view) {

        if(view == register)
        {
            registerUser();
        }
        if(view == loginifregister)
        {
            Intent intent = new Intent(getBaseContext(), LoginActivity.class);
            startActivity(intent);
        }
    }
}
