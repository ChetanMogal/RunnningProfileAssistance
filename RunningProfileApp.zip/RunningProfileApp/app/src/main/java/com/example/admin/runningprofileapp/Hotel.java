package com.example.admin.runningprofileapp;

import java.util.ArrayList;

/**
 * Created by ADMIN on 22-02-2019.
 */

public class Hotel
{
    Long id;
    String name;
    ArrayList<String> menu;
    public Hotel()
    {}
    public Hotel(Long id, String name, ArrayList menus) {
        this.id = id;
        this.name = name;
        this.menu = menus;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<String> getMenu() {
        return menu;
    }

    public void setMenu(ArrayList<String> menus) {
        this.menu = menus;
    }
}
