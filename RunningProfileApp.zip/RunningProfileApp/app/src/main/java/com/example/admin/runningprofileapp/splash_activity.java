package com.example.admin.runningprofileapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import android.os.Handler;
import java.util.logging.LogRecord;

/**
 * Created by ADMIN on 04-05-2019.
 */

public class splash_activity extends Activity {
    Handler handler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.logo_splash);

        handler=new Handler();
        handler.postDelayed(new Runnable(){
            @Override
            public void run(){
                Intent intent= new Intent(splash_activity.this,RegistrationActivity.class);
            startActivity(intent);
            finish();}
        },3000);
        }
}
