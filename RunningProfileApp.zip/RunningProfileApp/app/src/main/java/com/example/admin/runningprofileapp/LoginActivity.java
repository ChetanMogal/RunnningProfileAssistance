package com.example.admin.runningprofileapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.media.MediaPlayer;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{

    private Button Singin;
    private EditText email2, password2;
    private TextView signup;
    String email;
    private ProgressDialog progressDialog;

    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Singin = (Button) findViewById(R.id.Singin);
        email2 = (EditText) findViewById(R.id.email2);
        password2 = (EditText) findViewById(R.id.password2);
        signup = (TextView) findViewById(R.id.signup);

        progressDialog = new ProgressDialog(this);
        firebaseAuth = FirebaseAuth.getInstance();


        if(firebaseAuth.getCurrentUser() != null){
            finish();
            email=firebaseAuth.getCurrentUser().getEmail();
            //startActivity(new Intent(getApplicationContext(), ProfileActivity.class));
            Intent intent =new Intent(getApplicationContext(), ProfileActivity.class);
            intent.putExtra("email",email);
            startActivity(intent);
        }

        Singin.setOnClickListener(this);
        signup.setOnClickListener(this);

    }
    private void userLogin(){
        final String email=email2.getText().toString().trim();
        final String pass1=password2.getText().toString().trim();

        if(TextUtils.isEmpty(email)){
            //email is empty
            Toast.makeText(this,"Please enter the email", Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(pass1)){
            //password is empty
            Toast.makeText(this,"Please enter the password", Toast.LENGTH_SHORT).show();
            return;
        }
        progressDialog.setMessage("Login User...");
        progressDialog.show();
        firebaseAuth.signInWithEmailAndPassword(email,pass1).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                progressDialog.dismiss();
                if(task.isSuccessful()){
                    Toast.makeText(LoginActivity.this, "Login Successfully", Toast.LENGTH_SHORT).show();
                    finish();
                    //startActivity(new Intent(getApplicationContext(), ProfileActivity.class));
                    Intent intent =new Intent(getApplicationContext(), ProfileActivity.class);
                    intent.putExtra("email",email);
                    startActivity(intent);
                }
                else {
                    FirebaseAuthException e = (FirebaseAuthException )task.getException();
                    Log.d("TAG", "onComplete: email="+email+" pw="+pass1+" er="+e.getMessage());
                    Toast.makeText(LoginActivity.this, "Failed Login: "+e.getMessage(), Toast.LENGTH_SHORT).show();
                    Toast.makeText(LoginActivity.this, "Could not login. Please try again", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                }

            }
        });



    }
    @Override
    public void onClick(View view) {

        if(view == Singin){
            userLogin();
        }
        if(view == signup){
            finish();
            startActivity(new Intent(this, RegistrationActivity.class));
        }
    }
}
