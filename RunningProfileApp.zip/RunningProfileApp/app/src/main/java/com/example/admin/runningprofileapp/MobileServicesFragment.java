package com.example.admin.runningprofileapp;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

/**
 * Created by ADMIN on 08-04-2019.
 */

public class MobileServicesFragment extends Fragment implements OnMapReadyCallback {


    private GoogleMap mMap;
    SupportMapFragment mapFragment;
    DatabaseReference databaseReference;
    StorageReference storageReference;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View rootview=inflater.inflate(R.layout.fragment_mobileservices, container, false);
        Log.d("TAG", "oncreate: in.....mobileservices .......");
        SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);


        return rootview;
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        storageReference= FirebaseStorage.getInstance().getReference();
        DatabaseReference databaseReferencep= FirebaseDatabase.getInstance().getReference();
        databaseReference= databaseReferencep.child("SearchItem");


        Log.d("TAG", "oncreate: on map ready............");
        databaseReference.addValueEventListener(new ValueEventListener() {
            //Log.d("TAG", "onDataChange: in.....addValueEventListener.......");
            double totallang=0,totallat=0;
            int count=0;
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                mMap.clear();
                mMap.getUiSettings().setZoomControlsEnabled(true);
                mMap.getUiSettings().setMyLocationButtonEnabled(true);
                //Log.d("TAG", "onDataChange: in.....onDataChange.......");
                for(DataSnapshot ss: dataSnapshot.getChildren())
                {
                    SearchItem s = (SearchItem) ss.getValue(SearchItem.class);

                    //Log.d("TAG", "onMapReady: " + s);
                    // Add a marker and move the camera
                    LatLng latLng = new LatLng(s.getLat(), s.getLang());
                    if (s.getCategory().equalsIgnoreCase("mobile services"))
                    {

                        totallat += s.getLat();
                        totallang += s.getLang();
                        count++;
                        MarkerOptions markerOptions = new MarkerOptions();
                        markerOptions.title(s.getName());
                        markerOptions.position(latLng);
                        markerOptions.snippet(s.getAddress());
                        //markerOptions.icon(BitmapDescriptorFactory.fromResource(R.mipmap.police));

                        mMap.addMarker(markerOptions);
                    }

                }
                LatLng latLng = new LatLng(totallat / count, totallang /count);
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 13.0f));
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.d("TAG", "onDataChange: in.....onCancelled......."+databaseError.getDetails());
            }
        });
    }
}
