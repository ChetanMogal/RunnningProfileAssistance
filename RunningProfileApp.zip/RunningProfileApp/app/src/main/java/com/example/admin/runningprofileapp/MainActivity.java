package com.example.admin.runningprofileapp;

import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.constraint.solver.widgets.Snapshot;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

public class MainActivity extends AppCompatActivity {
    DatabaseReference databaseReference;
    StorageReference storageReference;
    TextView txtId, txtName;
    ImageView img;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtId =(TextView)findViewById(R.id.txtId);
        txtName =(TextView)findViewById(R.id.txtName);
        img  =(ImageView) findViewById(R.id.imgMenu);

        storageReference= FirebaseStorage.getInstance().getReference();
        databaseReference= FirebaseDatabase.getInstance().getReference("SearchItem");
        Log.d("TAG", "oncreate: in............");

    }

    @Override
    protected void onStart()
    {
        super.onStart();

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Log.d("TAG", "onDataChange: in............");
                for(DataSnapshot ss: dataSnapshot.getChildren())
                {

                    SearchItem s = (SearchItem) ss.getValue(SearchItem.class);


                    Log.d("TAG", "onMapReady: " + s.getName());
                    // Add a marker in Sydney and move the camera

                    /*Hotel hotel=(Hotel) ss.getValue(Hotel.class);

                    txtId.setText(hotel.getId().longValue()+"");
                    txtName.setText(hotel.getName()+"");
                    String imgstr=hotel.getMenu().get(1).toString();
                    Uri uri = Uri.parse(imgstr);
                    Log.d("TAG", "onDataChange: "+imgstr);
                    //Picasso.with(MainActivity.this).load(uri).fit().centerCrop().into(img  );

                    storageReference =FirebaseStorage.getInstance().getReferenceFromUrl(hotel.getMenu().get(1).toString());
                    storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            // mPregresDialog.dismiss();
                            Log.d("TAG", "onsuccess "+uri);
                            Picasso.with(MainActivity.this).load(uri).fit().centerCrop().into(img  );

                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception exception) {
                            //mPregresDialog.dismiss();
                            Toast.makeText(MainActivity.this, "Error", Toast.LENGTH_LONG).show();

                        }
                    });





                    Log.d("TAG", "onDataChange: "+storageReference);
//                    Picasso.with(getApplicationContext()).load(hotel.getMenu().get(1).toString()).into(img);
                    Picasso.with(MainActivity.this).load(storageReference.getPath()).fit().centerCrop().into(img);
                    Log.d("TAG", "onDataChange: "+hotel.getMenu().size()); */
                    /*for(DataSnapshot mchild:ss.getChildren())
                    {
                        String key=ss.getKey();

                        if(key.equals("menu"))
                        {
                        Log.d("TAG", "onDataChange: in............"+mchild);
                       //Menu menu   =mchild.getValue(Menu.class);

                        //Picasso.with(getApplicationContext()).load(menu.getMenuImages()[0]).into(img);              Log.d("TAG", "onDataChange: "+hotel.getId());
                        }
                    }*/
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

       /* storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
               // mPregresDialog.dismiss();
                Picasso.with(MainActivity.this).load(uri).fit().centerCrop().into(img  );

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                //mPregresDialog.dismiss();
                Toast.makeText(MainActivity.this, "Error", Toast.LENGTH_LONG).show();

            }
        });*/
    }
}
