package com.example.admin.runningprofileapp;

/**
 * Created by ADMIN on 22-02-2019.
 */

public class Menu
{
    String menuImages[];
    public Menu(){}
    public Menu(String menuImages[])
    {
        this.menuImages=menuImages;
    }

    public String[] getMenuImages() {
        return menuImages;
    }

    public void setMenuImages(String[] menuImages) {
        this.menuImages = menuImages;
    }
}
