package com.example.admin.runningprofileapp;

/**
 * Created by ADMIN on
 */

public class SearchItem {
    String category;
    String name;
    String address;
    String phoneno;
    double lat;
    double lang;
    public SearchItem()
    {

    }
    public SearchItem(String category, String name, String address, String phoneno, double lat, double lang) {
        this.category = category;
        this.name = name;
        this.address = address;
        this.phoneno = phoneno;
        this.lat = lat;
        this.lang = lang;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setPhoneno(String phoneno) {
        this.phoneno = phoneno;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public void setLang(double lang) {
        this.lang = lang;
    }

    public String getCategory() {
        return category;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getPhoneno() {
        return phoneno;
    }

    public double getLat() {
        return lat;
    }

    public double getLang() {
        return lang;
    }

    @Override
    public String toString() {
        return "SearchItem{" +
                "category='" + category + '\'' +
                ", name='" + name + '\'' +
                ", address='" + address + '\'' +
                ", phoneno='" + phoneno + '\'' +
                ", lat=" + lat +
                ", lang=" + lang +
                '}';
    }
}
